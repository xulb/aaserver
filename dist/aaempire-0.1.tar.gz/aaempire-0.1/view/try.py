import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from console import *

root = tk.Tk()
text = ScrolledText()
con = Console(text)
text.grid()
root.mainloop()

