
class testArgs:
    def __init__(self):
        self.host = 'xulbia.org'
        self.port = 27909
        self.passwd = '1haldane1'
            
